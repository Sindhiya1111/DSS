package com.example.DSSmain.repo;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import com.example.DSSmain.model.Skier;

@Repository
public interface SkierRepo extends MongoRepository<Skier, Integer>{
	
	List<Skier> findAll();
	
}