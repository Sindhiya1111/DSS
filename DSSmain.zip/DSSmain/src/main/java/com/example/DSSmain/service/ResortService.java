package com.example.DSSmain.service;
import java.util.List;

import com.example.DSSmain.model.*;

public interface ResortService {
	
	public Object addSeason(int resortID, String year);

	public Object addResort(int resortID, String resortName);

	List<Resort> getAllResort();
}
