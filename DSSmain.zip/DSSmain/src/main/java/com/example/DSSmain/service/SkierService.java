package com.example.DSSmain.service;

import java.util.List;

import com.example.DSSmain.model.*;

public interface SkierService {
	
	public Object addSkierInLift(Integer resortID, String seasonID, Integer dayID, Integer skierID, Integer time,
			Integer liftID);
	
	List<Skier> getAllSkier();

}

