package com.example.DSSmain;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DsSmainApplicationTests {

	@Test
	void contextLoads() {
	}

}
